package com.example;
/**
 * Created By: Ali Mohammadi
 * Date: 30 Nov, 2022
 */

public class Config {
  public static void SetProperty(){
    System.setProperty("javax.net.ssl.keyStore", "D:/key/key.jks");
    System.setProperty("javax.net.ssl.trustStore", "D:/key/trust.jks");
    System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
    System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
  }
}
