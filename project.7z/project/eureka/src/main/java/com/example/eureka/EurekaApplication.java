package com.example.eureka;

import com.example.Config;
import com.netflix.discovery.DiscoveryClient;
import com.netflix.discovery.shared.transport.jersey.EurekaJerseyClientImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.annotation.Bean;

import java.security.NoSuchAlgorithmException;

@SpringBootApplication
@EnableEurekaServer
public class EurekaApplication {
	public static void main(String[] args) {
		//Config.SetProperty();
		pro();
		SpringApplication.run(EurekaApplication.class, args);
	}
	
	public static void pro() {
		System.setProperty("javax.net.ssl.keyStore", "src/main/resources/key.jks");
		System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
		System.setProperty("javax.net.ssl.trustStore", "src/main/resources/trust.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

	}
}
